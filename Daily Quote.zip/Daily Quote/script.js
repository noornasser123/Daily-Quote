const quotes = [
    { quote: "Believe in yourself", author: "Noor" },
    { quote: "Dream big, start small.", author: "Noor" },
    { quote: "Stay consistent.", author: "Noor" },
    { quote: "Progress over perfection.", author: "Noor" }
];

const quoteText = document.getElementById('quote');
const authorText = document.getElementById('author');
const newQuoteBtn = document.getElementById("newQuote");

newQuoteBtn.addEventListener('click', () => {
    const random = quotes[Math.floor(Math.random() * quotes.length)];
    quoteText.textContent = `"${random.quote}"`;
    authorText.textContent = `- ${random.author}`;
}); 